package tests;

import application.backend.Backend;
import application.backend.questionSelection.Question;
import application.backend.questionSelection.QuestionSelection;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class GeneralTests {
    private Backend backend;
    private Question question;
    private int flagNumber;


    @Before
    public void setUp() throws InvocationTargetException, IllegalAccessException {
        backend = new Backend();

        QuestionSelection questionSelection;
        Field fields[] = backend.getClass().getDeclaredFields();
        fields[0].setAccessible(true);
        questionSelection = (QuestionSelection) fields[0].get(backend);

        fields = questionSelection.getClass().getDeclaredFields();
        fields[0].setAccessible(true);
        question = (Question) fields[0].get(questionSelection);
    }

    @Test
    public void flagCanBeFoundInEightQuestions(){
        int count = 0;
        backend.resetActiveFlags();
        while(backend.noFlagsLeft() || backend.oneFlagLeft() || backend.areTwoLastFlagsTheSame()){
            backend.getQuestion();
            backend.changeActiveFlagsAfterQuestion(question.getAnswerFor(flagNumber));
            count++;
        }
        if(backend.areTwoLastFlagsTheSame())
            count++;

        assertTrue(count <= 8);
    }

    @Test
    public void allFlagsCanBeFoundInEightQuestions() {
        for( flagNumber = 0; flagNumber <  backend.numberOfFlags(); flagNumber++)
            flagCanBeFoundInEightQuestions();

    }

}
