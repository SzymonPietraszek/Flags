package tests.unitTests;

import application.backend.ActiveFlags;
import application.backend.questionSelection.Conjunction;
import application.backend.questionSelection.QuestionSelection;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class QuestionSelectionTest {
    QuestionSelection questionSelection;

    @Before
    public void setUp(){
        questionSelection = new QuestionSelection(new ActiveFlags());
    }

    @Test
    public void ConjunctionsTest(){
        String actualString = "" + Conjunction.AND;
        assertEquals(" and ", actualString);
        actualString = "" + Conjunction.OR;
        assertEquals(" or ", actualString);
    }

    @Test
    public void firstQuestion(){
        assertEquals("Does your flag has green color or cross?", questionSelection.getQuestion());
    }

    @Test
    public void secondQuestion_afterYes(){
        questionSelection.getQuestion();
        questionSelection.changeActiveFlagsAfterQuestion(true);
        assertEquals("Does your flag has blue color or single color triangle?", questionSelection.getQuestion());
    }

    @Test
    public void secondQuestion_afterNo(){
        questionSelection.getQuestion();
        questionSelection.changeActiveFlagsAfterQuestion(false);
        assertEquals("Does your flag has exactly three colors?", questionSelection.getQuestion());
    }
}
