package tests.unitTests;

import application.backend.questionSelection.Conjunction;
import application.backend.data.Data;
import application.backend.questionSelection.QuestionSelection;
import org.junit.Test;

import static org.junit.Assert.*;

public class DataTest {

    @Test
    public void initialState() {
        assertFalse(Data.getAnswer(0, 0));
        assertTrue(Data.getAnswer(0, 3));
        assertEquals("green color", Data.getQuestion(1));
        assertEquals("at least one white rectangle", Data.getQuestion(Data.NUMBER_OF_QUESTIONS-1));
    }
}
