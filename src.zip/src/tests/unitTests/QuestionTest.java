package tests.unitTests;

import application.backend.ActiveFlags;
import application.backend.questionSelection.Conjunction;
import application.backend.questionSelection.Question;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class QuestionTest {

    @Test
    public void singleQuestion(){
        Question question = new Question(0,new ActiveFlags());
        assertEquals(false, question.getAnswerFor(0));
        assertEquals(true, question.getAnswerFor(3));
        assertEquals(19, question.getScore());
        assertEquals("Does your flag has blue color?",question.toString());
    }

    @Test
    public void bestFirstQuestion(){
        Question question = new Question(1,14, Conjunction.OR,new ActiveFlags());
        assertEquals(1, question.getScore());
    }
}
