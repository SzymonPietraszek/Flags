package tests.unitTests;

import application.backend.data.Data;
import application.backend.ActiveFlags;
import application.backend.questionSelection.Conjunction;
import application.backend.questionSelection.Question;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

public class ActiveFlagsTest {
    public ActiveFlags activeFlags;

    @Before
    public void setUp(){
        activeFlags = new ActiveFlags();
    }

    public boolean areAllFlagsActive() {
        for (int i = 0; i < Data.NUMBER_OF_FLAGS; i++)
            if (!activeFlags.isFlagActive(i))
                return false;
        return true;
    }

    @Test
    public void initialState() {
        assertFalse(activeFlags.noFlagsLeft());
        assertFalse(activeFlags.oneFlagLeft());
        assertEquals(0, activeFlags.getFirstActiveFlagNumber());
        assertFalse(activeFlags.areTwoLastFlagsTheSame());
        assertTrue(areAllFlagsActive());
    }

    @Test
    public void changeActiveFlags_withYes_shouldDeactivateSomeFlags() {
        activeFlags.changeActiveFlags(new Question(0, activeFlags),true);
        assertEquals("flag number 3 should be active after question number 0 with answer yes",
                true, activeFlags.isFlagActive(3));
        assertEquals(3, activeFlags.getFirstActiveFlagNumber());
        assertEquals("flag number 2 should be deactivated after question number 0 with answer yes",
                false, activeFlags.isFlagActive(2));
        assertEquals("first question should deactivate some flags", false, areAllFlagsActive());
        assertEquals("first question shouldn't deactivate all flags", false, activeFlags.noFlagsLeft());
    }

    @Test
    public void changeActiveFlags_withNo_shouldDeactivateSomeFlags() {
        activeFlags.changeActiveFlags(new Question(3, activeFlags),false);
        assertEquals("first question should deactivate some flags", false, areAllFlagsActive());
        assertEquals("first question shouldn't deactivate all flags", false, activeFlags.noFlagsLeft());
    }

    @Test
    public void changeActiveFlags_withTwoQuestions_shouldDeactivateSomeFlags() {
        activeFlags.changeActiveFlags(new Question(0, activeFlags),true);
        assertEquals("first question should deactivate some flags", false, areAllFlagsActive());
        assertEquals("first question shouldn't deactivate all flags", false, activeFlags.noFlagsLeft());
        activeFlags.changeActiveFlags(new Question(1, activeFlags),false);
        assertEquals("second question shouldn't deactivate all flags", false, activeFlags.noFlagsLeft());
    }

    @Test
    public void changeActiveFlags_withTwoOpositQuestions_shouldDeactivateAllFlags() {
        activeFlags.changeActiveFlags(new Question(0, activeFlags),true);
        activeFlags.changeActiveFlags(new Question(0, activeFlags),false);
        assertEquals("oposit questions should deactivate all flags", true, activeFlags.noFlagsLeft());
    }

    @Test
    public void changeActiveFlags_withTwoOpositQuestionsAnd_shouldDeactivateAllFlags() {
        activeFlags.changeActiveFlags(new Question(0, 1, Conjunction.AND, activeFlags), true);
        assertEquals("first question should deactivate some flags", false, areAllFlagsActive());
        assertEquals("first question shouldn't deactivate all flags", false, activeFlags.noFlagsLeft());
        activeFlags.changeActiveFlags(new Question(0, 1, Conjunction.AND, activeFlags), false);
        assertEquals("second oposit question should deactivate all flags", true, activeFlags.noFlagsLeft());
    }


    @Test
    public void changeActiveFlags_withTwoOpositQuestionsOr_shouldDeactivateAllFlags() {
        activeFlags.changeActiveFlags(new Question(0, 1, Conjunction.OR, activeFlags), true);
        assertEquals("first question should deactivate some flags", false, areAllFlagsActive());
        assertEquals("first question shouldn't deactivate all flags", false, activeFlags.noFlagsLeft());
        activeFlags.changeActiveFlags(new Question(0, 1, Conjunction.OR, activeFlags), false);
        assertEquals("second oposit question should deactivate all flags", true, activeFlags.noFlagsLeft());
    }

    @Test(expected = java.lang.AssertionError.class)
    public void getFirstActiveFlagNumber_withNoFlags_shouldReturnAssertionError(){
        activeFlags.changeActiveFlags(new Question(0,activeFlags), true);
        activeFlags.changeActiveFlags(new Question(0,activeFlags), false);
        assertFalse(activeFlags.noFlagsLeft());
        activeFlags.getFirstActiveFlagNumber();
    }
}
